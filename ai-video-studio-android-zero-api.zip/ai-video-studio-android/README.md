# AI Video Studio — Android Local (Zero API)

A small native Android app that creates a 16-second, 720x1280 H.264 MP4 locally on the phone. It does not call ChatGPT, OpenAI, Runway, or any server. No account, API key, VPS, or subscription is required.

## What it actually does

- One prompt screen and one output session.
- Optional product-photo picker.
- Builds four timed scenes from the user's brief.
- Applies animated background lighting, slow product-image movement, title cards, typography, and a progress line.
- Encodes the result as H.264 MP4 using Android `MediaCodec` and `MediaMuxer`.
- Saves the result to `Movies/AI Video Studio` and previews it in the app.

## Important capability boundary

This is a local motion-graphics video maker, not a text-to-video diffusion model. It cannot invent realistic moving footage, photorealistic CGI, or new product views from text. For the product to appear accurately, choose a real product photo. Without a photo, it creates typography-led scenes. No internet access or paid service is required.

## Build the APK without a PC (using GitHub on your phone)

1. Create a new empty GitHub repository.
2. Upload the contents of this folder to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow**. You can also push to `main` to trigger it.
5. When the workflow completes, open its run and download the `ai-video-studio-debug-apk` artifact.
6. Extract the artifact on Android and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Build with Android Studio

- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Android SDK platform 35

Run:

```bash
gradle assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Device notes

- Minimum Android API: 26 (Android 8.0).
- Default output: 720x1280 portrait, 30 fps, 16 seconds.
- Rendering is CPU/GPU and hardware-encoder dependent. Keep the app in the foreground and ensure sufficient free storage and battery.
- Some low-memory or vendor-modified devices may not expose a compatible AVC surface encoder. If rendering fails, the app displays the error rather than pretending a video was created.
- Source is unsigned debug build; suitable for personal installation/testing, not Play Store publication.
