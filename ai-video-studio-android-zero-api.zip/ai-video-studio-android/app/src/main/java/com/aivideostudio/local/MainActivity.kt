package com.aivideostudio.local

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.concurrent.Executors

class MainActivity : android.app.Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val renderer = VideoRenderer()
    private var productBitmap: Bitmap? = null
    private var selectedImageName: String? = null
    private lateinit var prompt: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var preview: VideoView
    private lateinit var generate: Button
    private lateinit var imageLabel: TextView

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) loadProductImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(Color.rgb(13, 19, 16))
        }
        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        val brand = text("AI VIDEO STUDIO", 13f, Color.rgb(190, 242, 135), true).apply { letterSpacing = 0.12f }
        root.addView(brand, lp(-1, -2, 0, 0, 0, 12))
        root.addView(text("Make a video.\nNot a slideshow.", 30f, Color.WHITE, true), lp(-1, -2, 0, 0, 0, 8))
        root.addView(text("Describe the advertisement. Add a product photo if you have one. Your phone creates the video locally.", 14f, Color.rgb(177, 190, 181), false), lp(-1, -2, 0, 0, 0, 18))

        prompt = EditText(this).apply {
            hint = "Example: Create a premium cinematic product ad with dramatic lighting, macro details, smooth camera movement and bold typography..."
            setHintTextColor(Color.rgb(125, 141, 130)); setTextColor(Color.WHITE)
            textSize = 15f; gravity = Gravity.TOP
            minLines = 5; maxLines = 9
            setPadding(dp(15), dp(14), dp(15), dp(14))
            setBackgroundColor(Color.rgb(29, 40, 33))
        }
        root.addView(prompt, lp(-1, -2, 0, 0, 0, 12))

        val imageButton = Button(this).apply {
            text = "＋  Add product photo (optional)"
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 57, 46)))
            setOnClickListener { imagePicker.launch("image/*") }
        }
        root.addView(imageButton, lp(-1, dp(52), 0, 0, 0, 4))
        imageLabel = text("No product image selected", 12f, Color.rgb(151, 166, 155), false)
        root.addView(imageLabel, lp(-1, -2, 0, 4, 0, 14))

        generate = Button(this).apply {
            text = "GENERATE VIDEO  →"
            textSize = 15f; isAllCaps = false
            setTextColor(Color.rgb(18, 29, 17))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 242, 135)))
            setOnClickListener { startRender() }
        }
        root.addView(generate, lp(-1, dp(56), 0, 0, 0, 14))

        status = text("READY · All processing happens on this phone", 13f, Color.rgb(190, 242, 135), true)
        root.addView(status, lp(-1, -2, 0, 4, 0, 8))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(190, 242, 135))
        }
        root.addView(progress, lp(-1, dp(6), 0, 0, 0, 18))

        root.addView(text("OUTPUT SESSION", 12f, Color.rgb(190, 242, 135), true), lp(-1, -2, 0, 8, 0, 8))
        preview = VideoView(this).apply {
            setBackgroundColor(Color.rgb(24, 32, 27))
            visibility = View.GONE
        }
        root.addView(preview, lp(-1, dp(380), 0, 0, 0, 8))
        root.addView(text("Your finished MP4 will appear here.\n\nTip: add a clear product image for a more recognisable product-focused result. Without one, the renderer creates a typography-led motion graphic.", 13f, Color.rgb(151, 166, 155), false), lp(-1, -2, 0, 0, 0, 12))
    }

    private fun startRender() {
        val brief = prompt.text.toString().trim()
        if (brief.length < 12) { toast("Describe the video first."); return }
        generate.isEnabled = false
        preview.visibility = View.GONE
        progress.progress = 0
        status.text = "PREPARING · Building scenes on your phone…"
        executor.execute {
            try {
                val output = File(cacheDir, "ad_${System.currentTimeMillis()}.mp4")
                val config = VideoRenderer.RenderConfig(prompt = brief, productImage = productBitmap)
                val worker = Thread {
                    while (!Thread.currentThread().isInterrupted) {
                        runOnUiThread {
                            progress.progress = renderer.progress
                            if (renderer.progress > 0 && renderer.progress < 100) status.text = "RENDERING · ${renderer.progress}% · Keep the app open"
                        }
                        if (renderer.progress >= 100) break
                        try { Thread.sleep(400) } catch (_: InterruptedException) { break }
                    }
                }
                renderer.progress = 0
                worker.start()
                renderer.render(config, output)
                worker.interrupt()
                val saved = saveToMovies(output)
                runOnUiThread {
                    progress.progress = 100
                    status.text = "COMPLETE · Saved to Movies/AI Video Studio"
                    preview.visibility = View.VISIBLE
                    preview.setVideoURI(Uri.fromFile(output))
                    preview.setOnPreparedListener { it.isLooping = true; preview.start() }
                    generate.isEnabled = true
                    toast("Video saved to Movies/AI Video Studio")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "RENDER FAILED · ${e.message ?: "Unknown error"}"
                    generate.isEnabled = true
                    toast("Rendering failed: ${e.message}")
                }
            }
        }
    }

    private fun loadProductImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { input ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(contentResolver.openInputStream(uri), null, options)
                var sample = 1
                while (options.outWidth / sample > 1800 || options.outHeight / sample > 1800) sample *= 2
                val bitmapOptions = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                productBitmap = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bitmapOptions) }
            }
            selectedImageName = "Product photo selected"
            imageLabel.text = "✓ Product photo ready"
        } catch (e: Exception) { toast("Could not open that image") }
    }

    private fun saveToMovies(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "AI_Ad_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AI Video Studio")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri).use { out -> FileInputStream(file).use { input -> input.copyTo(out!!) } }
        return uri
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun lp(width: Int, height: Int, left: Int, top: Int, right: Int, bottom: Int) = LinearLayout.LayoutParams(width, height).apply {
        setMargins(left, top, right, bottom)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() { super.onDestroy(); executor.shutdownNow(); productBitmap?.recycle() }
}
