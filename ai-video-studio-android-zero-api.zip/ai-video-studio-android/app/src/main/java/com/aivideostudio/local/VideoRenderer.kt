package com.aivideostudio.local

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.min
import kotlin.math.max

/** Offline motion-graphics renderer. It creates a real H.264 MP4 locally; no API or server is used. */
class VideoRenderer {
    data class RenderConfig(
        val prompt: String,
        val productImage: Bitmap?,
        val width: Int = 720,
        val height: Int = 1280,
        val fps: Int = 30,
        val secondsPerScene: Int = 4
    )

    private var videoTrackIndex: Int = 0
    @Volatile var progress: Int = 0

    fun render(config: RenderConfig, output: File) {
        require(config.width % 2 == 0 && config.height % 2 == 0)
        output.parentFile?.mkdirs()
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, config.width, config.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 5_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, config.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var surface: Surface? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var trackIndex = -1
        val bufferInfo = MediaCodec.BufferInfo()
        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = encoder.createInputSurface()
            encoder.start()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val scenes = buildScenes(config.prompt)
            val totalFrames = scenes.size * config.secondsPerScene * config.fps
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val frameDelay = 1000L / config.fps
            var rendered = 0

            for (sceneIndex in scenes.indices) {
                val scene = scenes[sceneIndex]
                val sceneFrames = config.secondsPerScene * config.fps
                for (frame in 0 until sceneFrames) {
                    val canvas: Canvas = surface.lockCanvas(null)
                    try {
                        val localT = frame.toFloat() / max(1, sceneFrames - 1)
                        drawFrame(canvas, config, scene, sceneIndex, localT, paint)
                    } finally {
                        surface.unlockCanvasAndPost(canvas)
                    }
                    drainEncoder(encoder, muxer, bufferInfo, false) { index ->
                        if (!muxerStarted) { trackIndex = muxer!!.addTrack(encoder.outputFormat); videoTrackIndex = trackIndex; muxer!!.start(); muxerStarted = true }
                    }
                    rendered++
                    progress = (rendered * 95 / totalFrames).coerceIn(1, 95)
                    Thread.sleep(frameDelay)
                }
            }
            encoder.signalEndOfInputStream()
            var finished = false
            while (!finished) {
                val status = drainEncoder(encoder, muxer, bufferInfo, true) { if (!muxerStarted) { trackIndex = muxer!!.addTrack(encoder.outputFormat); videoTrackIndex = trackIndex; muxer!!.start(); muxerStarted = true } }
                finished = status
            }
            progress = 100
        } finally {
            try { surface?.release() } catch (_: Exception) {}
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun drainEncoder(
        encoder: MediaCodec,
        muxer: MediaMuxer?,
        info: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onFormat: (Int) -> Unit
    ): Boolean {
        var eos = false
        while (true) {
            val index = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return eos
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(index)
                index >= 0 -> {
                    val encoded = encoder.getOutputBuffer(index)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && encoded != null && muxer != null) {
                        encoded.position(info.offset)
                        encoded.limit(info.offset + info.size)
                        muxer.writeSampleData(videoTrackIndex, encoded, info)
                    }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
                    encoder.releaseOutputBuffer(index, false)
                    if (eos) return true
                }
            }
        }
    }

    private data class Scene(val eyebrow: String, val headline: String, val detail: String)

    private fun buildScenes(prompt: String): List<Scene> {
        val clean = prompt.trim().replace(Regex("\\s+"), " ")
        val title = clean.split(Regex("(?i)\\b(for|with|featuring|show)\\b"))
            .firstOrNull()?.take(58)?.trim()?.trim('.', ',', ':')?.ifBlank { "YOUR PRODUCT" } ?: "YOUR PRODUCT"
        val lower = clean.lowercase()
        val features = listOf("ANC", "battery", "driver", "waterproof", "camera", "display", "speed", "sound")
            .filter { lower.contains(it) }
        val feature1 = features.getOrNull(0)?.uppercase() ?: "DESIGNED TO IMPRESS"
        val feature2 = features.getOrNull(1)?.uppercase() ?: "DETAILS THAT MATTER"
        return listOf(
            Scene("INTRODUCING", title.uppercase(), "A closer look at what makes it stand out."),
            Scene("ENGINEERED FOR", feature1, "Purposeful design. Carefully considered details."),
            Scene("MADE FOR EVERY DAY", feature2, "Performance and design, working together."),
            Scene("MAKE IT YOURS", title.uppercase(), "Discover the difference. Experience more.")
        )
    }

    private fun drawFrame(canvas: Canvas, cfg: RenderConfig, scene: Scene, sceneIndex: Int, t: Float, p: Paint) {
        val w = canvas.width.toFloat(); val h = canvas.height.toFloat()
        val palettes = arrayOf(intArrayOf(Color.rgb(9, 18, 22), Color.rgb(26, 48, 51)), intArrayOf(Color.rgb(18, 16, 30), Color.rgb(52, 37, 67)), intArrayOf(Color.rgb(12, 22, 35), Color.rgb(31, 55, 75)), intArrayOf(Color.rgb(11, 20, 17), Color.rgb(35, 61, 42)))
        val colors = palettes[sceneIndex % palettes.size]
        p.shader = LinearGradient(0f, 0f, w, h, colors[0], colors[1], Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p); p.shader = null
        // Soft cinematic light pools.
        p.color = Color.argb(35, 210, 255, 230)
        canvas.drawCircle(w * (0.78f - 0.08f * t), h * 0.34f, w * 0.46f, p)
        p.color = Color.argb(24, 130, 170, 255)
        canvas.drawCircle(w * 0.12f, h * 0.76f, w * 0.34f, p)

        val image = cfg.productImage
        if (image != null && !image.isRecycled) {
            val maxW = w * 0.78f; val maxH = h * 0.43f
            val scale = min(maxW / image.width, maxH / image.height) * (1.0f + 0.055f * t)
            val dw = image.width * scale; val dh = image.height * scale
            val cx = w * 0.5f + (t - 0.5f) * 18f
            val cy = h * 0.43f
            p.setShadowLayer(28f, 0f, 18f, Color.BLACK)
            canvas.drawBitmap(image, null, RectF(cx - dw/2, cy - dh/2, cx + dw/2, cy + dh/2), p)
            p.clearShadowLayer()
        } else {
            p.color = Color.argb(45, 255, 255, 255)
            canvas.drawRoundRect(RectF(w*0.18f, h*0.25f, w*0.82f, h*0.57f), 34f, 34f, p)
            p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = w*0.12f; p.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            canvas.drawText("PRODUCT", w/2, h*0.43f, p)
        }

        p.color = Color.argb(180, 190, 242, 135); p.textAlign = Paint.Align.CENTER
        p.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        p.textSize = w * 0.031f
        canvas.drawText(scene.eyebrow, w/2, h*0.72f, p)
        p.color = Color.WHITE; p.textSize = w * 0.064f
        drawCenteredWrapped(canvas, scene.headline, w/2, h*0.78f, w*0.86f, p, 2)
        p.color = Color.argb(220, 225, 232, 229); p.textSize = w * 0.031f
        drawCenteredWrapped(canvas, scene.detail, w/2, h*0.88f, w*0.82f, p, 2)
        p.color = Color.argb(120, 255, 255, 255); p.textSize = w*0.022f
        canvas.drawText("AI VIDEO STUDIO  •  LOCAL RENDER", w/2, h*0.96f, p)
        // Animated progress line.
        p.color = Color.argb(75, 255, 255, 255); canvas.drawRoundRect(w*0.12f, h*0.065f, w*0.88f, h*0.069f, 8f, 8f, p)
        p.color = Color.rgb(190, 242, 135); canvas.drawRoundRect(w*0.12f, h*0.065f, w*(0.12f + 0.76f*((sceneIndex+t)/4f)), h*0.069f, 8f, 8f, p)
    }

    private fun drawCenteredWrapped(canvas: Canvas, text: String, centerX: Float, y: Float, maxWidth: Float, paint: Paint, maxLines: Int) {
        val words = text.split(" ")
        val lines = mutableListOf<String>(); var line = ""
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(candidate) <= maxWidth || line.isEmpty()) line = candidate
            else { lines.add(line); line = word }
            if (lines.size >= maxLines) break
        }
        if (lines.size < maxLines && line.isNotEmpty()) lines.add(line)
        val lineHeight = paint.textSize * 1.18f
        lines.forEachIndexed { i, value -> canvas.drawText(value, centerX, y + i*lineHeight, paint) }
    }
}
